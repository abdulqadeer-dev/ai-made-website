const scroll = new LocomotiveScroll({
    el: document.querySelector('.website-main'),
    smooth: true
});